package com.intellij.database.model;

public interface DasHideableObject extends DasObject {
  boolean isHidden();
}