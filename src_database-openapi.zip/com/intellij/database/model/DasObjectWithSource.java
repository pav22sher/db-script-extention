package com.intellij.database.model;

public interface DasObjectWithSource extends DasObject {
}
