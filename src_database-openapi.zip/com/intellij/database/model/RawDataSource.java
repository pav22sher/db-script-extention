package com.intellij.database.model;

import org.jetbrains.annotations.Nullable;

public interface RawDataSource extends DasDataSource {
  @Nullable
  String getGroupName();
  boolean isGlobal();
}
