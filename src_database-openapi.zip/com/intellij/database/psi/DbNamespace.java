package com.intellij.database.psi;

import com.intellij.database.model.DasNamespace;

public interface DbNamespace extends DbElement, DasNamespace {
}
