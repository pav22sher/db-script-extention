package com.intellij.database.psi;

import com.intellij.database.model.DasObject;
import org.jetbrains.annotations.NotNull;

public interface DbObject extends DbElement {
  @Override
  @NotNull
  DasObject getDelegate();

  @Override
  @NotNull
  DbElement getDasParent();

  @Override
  @NotNull
  DbElement getParent();
}
