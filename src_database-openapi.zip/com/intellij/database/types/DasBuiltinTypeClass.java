package com.intellij.database.types;

import org.jetbrains.annotations.NotNull;

public interface DasBuiltinTypeClass<C extends DasTypeClass> extends DasTypeClass {
  @NotNull
  DasTypeCategory getCategory();

  @NotNull
  DasBuiltinTypeClass<C> getCanonical();

  @NotNull
  C withName(@NotNull String newName);
}
