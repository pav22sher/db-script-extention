package com.intellij.database.types;

import com.intellij.database.model.ScaleConstant;
import com.intellij.database.model.SizeConstant;
import org.jetbrains.annotations.NotNull;

public interface DasBuiltinTypeWithPrecision<C extends DasBuiltinTypeClass<C>> extends DasBuiltinType<C> {
  @SizeConstant
  int getPrecision();

  @ScaleConstant
  int getScale();

  @NotNull
  DasBuiltinTypeWithPrecision<C> copy(@SizeConstant int precision, @ScaleConstant int scale);
}