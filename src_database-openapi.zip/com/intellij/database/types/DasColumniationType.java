package com.intellij.database.types;

import com.intellij.database.model.DasTypedObject;
import org.jetbrains.annotations.NotNull;

public interface DasColumniationType extends DasType {
  @NotNull
  DasScope<DasTypedObject> getColumnScope();
}
