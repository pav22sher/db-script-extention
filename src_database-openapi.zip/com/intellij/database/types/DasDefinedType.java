package com.intellij.database.types;

import org.jetbrains.annotations.NotNull;

public interface DasDefinedType extends DasType {
  @NotNull
  @Override
  DasDefinedTypeClass getTypeClass();
}