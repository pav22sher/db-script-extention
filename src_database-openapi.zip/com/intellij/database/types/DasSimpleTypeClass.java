package com.intellij.database.types;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class DasSimpleTypeClass implements DasTypeClass {
  private final String myName;

  public DasSimpleTypeClass(String name) { myName = name; }

  @Nullable
  @Override
  public String getSchemaName() {
    return null;
  }

  @Nullable
  @Override
  public String getPackageName() {
    return null;
  }

  @NotNull
  @Override
  public String getName() {
    return myName;
  }
}