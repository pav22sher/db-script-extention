package com.intellij.database.types;

public interface DasTableType extends DasType {
  int getColumnCount();

  DasType getColumnDasType(int i);
}