package com.intellij.database.types;

import java.sql.Types;

public enum DasTypeCategory {
  INTEGER,
  REAL,
  STRING,
  BOOLEAN,
  DATE_TIME,
  DATE,
  TIME,
  TIMESTAMP,
  INTERVAL,
  BYTES,
  ENUM,
  REFERENCE,
  RECORD, // only unstructured records (like Postgres ones)
  UNKNOWN;

  DasTypeCategory() {
  }

  public boolean isNumber() {
    return this == INTEGER || this == REAL;
  }

  public static DasTypeCategory findByJdbcType(final int jdbcType) {
    return switch (jdbcType) {
      case Types.BIT, Types.TINYINT, Types.SMALLINT, Types.INTEGER, Types.BIGINT, Types.CHAR -> INTEGER;
      case Types.FLOAT, Types.REAL, Types.DOUBLE, Types.NUMERIC, Types.DECIMAL -> REAL;
      case Types.VARCHAR, Types.LONGVARCHAR, Types.CLOB, Types.NCLOB -> STRING;
      case Types.DATE -> DATE;
      case Types.TIME -> TIME;
      case Types.TIMESTAMP -> TIMESTAMP;
      case Types.BINARY, Types.VARBINARY, Types.LONGVARBINARY, Types.JAVA_OBJECT, Types.BLOB -> BYTES;
      case Types.BOOLEAN -> BOOLEAN;
      default -> UNKNOWN;
    };
  }
}
