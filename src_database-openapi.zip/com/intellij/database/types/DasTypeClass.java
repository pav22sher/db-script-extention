package com.intellij.database.types;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public interface DasTypeClass {
  @Nullable
  String getSchemaName();

  @Nullable
  String getPackageName();

  @NotNull
  String getName();
}