package com.intellij.database.types;

import com.intellij.openapi.application.ApplicationManager;
import org.jetbrains.annotations.NotNull;

public abstract class DasTypeFacade {
  @NotNull
  public abstract DasBuiltinType<?> getUnknown();

  @NotNull
  public static DasTypeFacade getInstance() {
    return ApplicationManager.getApplication().getService(DasTypeFacade.class);
  }

  @NotNull
  public static DasType resolve(@NotNull DasType dasType) {
    return dasType instanceof DasTypeReference ? ((DasTypeReference)dasType).resolve() : dasType;
  }
}