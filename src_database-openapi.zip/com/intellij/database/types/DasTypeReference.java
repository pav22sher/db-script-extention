package com.intellij.database.types;

import org.jetbrains.annotations.NotNull;

public interface DasTypeReference extends DasType {
  @NotNull
  DasType resolve();
}