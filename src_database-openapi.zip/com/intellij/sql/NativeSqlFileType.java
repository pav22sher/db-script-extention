package com.intellij.sql;

import com.intellij.openapi.fileTypes.LanguageFileType;
import com.intellij.sql.dialects.SqlLanguageDialect;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;

import javax.swing.*;

public abstract class NativeSqlFileType extends LanguageFileType {
  private final String myDefaultExtension;
  private final Icon myIcon;

  protected NativeSqlFileType(@NotNull SqlLanguageDialect dialect, @NotNull String defaultExtension, @NotNull Icon icon) {
    super(dialect);
    myDefaultExtension = defaultExtension;
    myIcon = icon;
  }

  @NotNull
  private SqlLanguageDialect getSqlDialect() {
    return (SqlLanguageDialect) getLanguage();
  }

  @Override
  @NotNull
  @NonNls
  public final String getName() {
    return getSqlDialect().getID();
  }

  @Override
  @NotNull
  public final String getDescription() {
    return getName(); //NON-NLS
  }

  @NotNull
  @Override
  public String getDefaultExtension() {
    return myDefaultExtension;
  }

  @Override
  public final Icon getIcon() {
    return myIcon;
  }
}
