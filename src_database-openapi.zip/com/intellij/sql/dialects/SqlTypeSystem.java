package com.intellij.sql.dialects;

import com.intellij.database.DbmsExtension;
import com.intellij.database.model.DataType;
import com.intellij.database.types.DasType;
import com.intellij.database.types.DasTypeCategory;
import com.intellij.sql.psi.SqlType;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public abstract class SqlTypeSystem {
  public static final DbmsExtension<SqlTypeSystem> EP = new DbmsExtension<>("com.intellij.sql.typeSystem");

  protected SqlTypeSystem() {
  }

  public abstract SqlType booleanType();

  public abstract SqlType stringType();

  public abstract SqlType integerType();

  public abstract SqlType realType();

  public abstract SqlType dateType();

  public abstract SqlType timeType();

  public abstract SqlType timestampType();

  public abstract SqlType dateTimeType();

  @NotNull
  public abstract String getNormalizedTypeName(@NotNull String name);

  @NotNull
  public abstract DataType normalizeType(@NotNull DataType type);

  @Nullable
  public abstract String getDefaultTypeName(@NotNull DasTypeCategory cat);

  @NotNull
  public abstract DasTypeCategory getTypeCategory(@NotNull DataType dataType);

  public abstract DasTypeCategory getTypeCategory(@NotNull DasType dasType);
}
