package com.intellij.sql.editor;

import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.components.PersistentStateComponent;
import com.intellij.openapi.components.SettingsCategory;
import com.intellij.openapi.components.State;
import com.intellij.openapi.components.Storage;
import com.intellij.sql.SqlBundle;
import com.intellij.util.xmlb.Converter;
import com.intellij.util.xmlb.annotations.OptionTag;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;

@State(
  name = "SqlEditorOptions",
  storages = @Storage("editor.xml"),
  category = SettingsCategory.CODE
)
public class SqlEditorOptions implements PersistentStateComponent<SqlEditorOptions> {
  private boolean myConcatenateStringsOnEnter = true;
  private boolean myCloseBlocksOnEnter = true;

  private static final QualificationType DEFAULT_QUALIFICATION_WITH = QualificationType.ALWAYS;
  private static final QualificationType DEFAULT_QUALIFICATION_IN = QualificationType.SMART;
  private static final QualificationType DEFAULT_JOIN_QUALIFICATION = QualificationType.ALWAYS;

  // Qualify what

  private @NotNull QualificationType myDatabaseQualification = DEFAULT_QUALIFICATION_WITH;
  private @NotNull QualificationType mySchemaQualification = DEFAULT_QUALIFICATION_WITH;
  private @NotNull QualificationType myTableQualification = DEFAULT_QUALIFICATION_WITH;
  private @NotNull QualificationType myAliasQualification = DEFAULT_QUALIFICATION_WITH;

  // Qualify where

  private @NotNull QualificationType myCompletionQualification = DEFAULT_QUALIFICATION_IN;
  private @NotNull QualificationType myJoinConditionQualification = DEFAULT_JOIN_QUALIFICATION;
  private @NotNull QualificationType myRefactoringQualification = DEFAULT_QUALIFICATION_IN;
  private @NotNull QualificationType myLiveTemplateQualification = DEFAULT_QUALIFICATION_IN;
  private @NotNull QualificationType myDragAndDropQualification = DEFAULT_QUALIFICATION_IN;

  private SqlEditorOptions load(SqlEditorOptions options) {
    myConcatenateStringsOnEnter = options.myConcatenateStringsOnEnter;
    myCloseBlocksOnEnter = options.myCloseBlocksOnEnter;
    myDatabaseQualification = options.myDatabaseQualification;
    mySchemaQualification = options.mySchemaQualification;
    myTableQualification = options.myTableQualification;
    myAliasQualification = options.myAliasQualification;
    myCompletionQualification = options.myCompletionQualification;
    myJoinConditionQualification = options.myJoinConditionQualification;
    myRefactoringQualification = options.myRefactoringQualification;
    myLiveTemplateQualification = options.myLiveTemplateQualification;
    myDragAndDropQualification = options.myDragAndDropQualification;
    return this;
  }

  @Nullable
  @Override
  public SqlEditorOptions getState() {
    return new SqlEditorOptions().load(this);
  }

  @Override
  public void loadState(@NotNull SqlEditorOptions state) {
    this.load(state);
  }

  public boolean isConcatenateStringsOnEnter() {
    return myConcatenateStringsOnEnter;
  }

  public void setConcatenateStringsOnEnter(boolean concatenateStringsOnEnter) {
    myConcatenateStringsOnEnter = concatenateStringsOnEnter;
  }

  public boolean isCloseBlocksOnEnter() {
    return myCloseBlocksOnEnter;
  }

  public void setCloseBlocksOnEnter(boolean closeBlocksOnEnter) {
    myCloseBlocksOnEnter = closeBlocksOnEnter;
  }

  @NotNull
  public QualificationType getDatabaseQualification() {
    return myDatabaseQualification;
  }

  @OptionTag(converter = QualificationTypeConverter.class)
  public void setDatabaseQualification(@Nullable QualificationType type) {
    myDatabaseQualification = type != null ? type : DEFAULT_QUALIFICATION_WITH;
  }

  @NotNull
  public QualificationType getSchemaQualification() {
    return mySchemaQualification;
  }

  @OptionTag(converter = QualificationTypeConverter.class)
  public void setSchemaQualification(@Nullable QualificationType type) {
    mySchemaQualification = type != null ? type : DEFAULT_QUALIFICATION_WITH;
  }

  /**
   * @deprecated This method exists only to ensure compatibility with older version of settings
   */
  @Deprecated
  public QualificationType getNamespaceQualification() {
    return null;
  }

  /**
   * @deprecated This method exists only to ensure compatibility with older version of settings
   */
  @Deprecated
  @OptionTag(converter = QualificationTypeConverter.class)
  public void setNamespaceQualification(@Nullable QualificationType type) {
    setDatabaseQualification(type);
    setSchemaQualification(type);
  }

  @NotNull
  public QualificationType getTableQualification() {
    return myTableQualification;
  }

  @OptionTag(converter = QualificationTypeConverter.class)
  public void setTableQualification(@Nullable QualificationType type) {
    myTableQualification = type != null ? type : DEFAULT_QUALIFICATION_WITH;
  }

  @NotNull
  public QualificationType getAliasQualification() {
    return myAliasQualification;
  }

  @OptionTag(converter = QualificationTypeConverter.class)
  public void setAliasQualification(@Nullable QualificationType type) {
    myAliasQualification = type != null ? type : DEFAULT_QUALIFICATION_WITH;
  }

  @NotNull
  public QualificationType getCompletionQualification() {
    return myCompletionQualification;
  }

  @OptionTag(converter = QualificationTypeConverter.class)
  public void setCompletionQualification(@Nullable QualificationType type) {
    myCompletionQualification = type != null ? type : DEFAULT_QUALIFICATION_IN;
  }

  @NotNull
  public QualificationType getJoinConditionQualification() {
    return myJoinConditionQualification;
  }

  @OptionTag(converter = QualificationTypeConverter.class)
  public void setJoinConditionQualification(@Nullable QualificationType type) {
    myJoinConditionQualification = type != null ? type : DEFAULT_JOIN_QUALIFICATION;
  }

  @NotNull
  public QualificationType getRefactoringQualification() {
    return myRefactoringQualification;
  }

  @OptionTag(converter = QualificationTypeConverter.class)
  public void setRefactoringQualification(@Nullable QualificationType type) {
    myRefactoringQualification = type != null ? type : DEFAULT_QUALIFICATION_IN;
  }

  @NotNull
  public QualificationType getLiveTemplateQualification() {
    return myLiveTemplateQualification;
  }

  @OptionTag(converter = QualificationTypeConverter.class)
  public void setLiveTemplateQualification(@Nullable QualificationType type) {
    myLiveTemplateQualification = type != null ? type : DEFAULT_QUALIFICATION_IN;
  }

  @NotNull
  public QualificationType getDragAndDropQualification() {
    return myDragAndDropQualification;
  }

  @OptionTag(converter = QualificationTypeConverter.class)
  public void setDragAndDropQualification(@Nullable QualificationType type) {
    myDragAndDropQualification = type != null ? type : DEFAULT_QUALIFICATION_IN;
  }

  @NotNull
  public static SqlEditorOptions getInstance() {
    return ApplicationManager.getApplication().getService(SqlEditorOptions.class);
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;
    SqlEditorOptions options = (SqlEditorOptions)o;
    return myConcatenateStringsOnEnter == options.myConcatenateStringsOnEnter &&
           myCloseBlocksOnEnter == options.myCloseBlocksOnEnter &&
           myDatabaseQualification == options.myDatabaseQualification &&
           mySchemaQualification == options.mySchemaQualification &&
           myTableQualification == options.myTableQualification &&
           myAliasQualification == options.myAliasQualification &&
           myCompletionQualification == options.myCompletionQualification &&
           myJoinConditionQualification == options.myJoinConditionQualification &&
           myRefactoringQualification == options.myRefactoringQualification &&
           myLiveTemplateQualification == options.myLiveTemplateQualification &&
           myDragAndDropQualification == options.myDragAndDropQualification;
  }

  @Override
  public int hashCode() {
    return Objects.hash(myConcatenateStringsOnEnter,
                        myCloseBlocksOnEnter,
                        myDatabaseQualification,
                        mySchemaQualification,
                        myTableQualification,
                        myAliasQualification,
                        myCompletionQualification,
                        myJoinConditionQualification,
                        myRefactoringQualification,
                        myLiveTemplateQualification,
                        myDragAndDropQualification);
  }

  public enum QualificationType {
    ALWAYS {
      @Override
      public boolean shouldQualify(int conflictedObjectsCount) {
        return true;
      }

      @NotNull
      @Override
      public QualificationType and(@NotNull QualificationType type) {
        return type;
      }

      @NotNull
      @Override
      public String getDisplayName() {
        return SqlBundle.message("settings.smart.keys.always");
      }
    },
    SMART {
      @Override
      public boolean shouldQualify(int conflictedObjectsCount) {
        return conflictedObjectsCount > 1;
      }

      @NotNull
      @Override
      public QualificationType and(@NotNull QualificationType type) {
        return type == NOT_QUALIFY ? type : this;
      }

      @NotNull
      @Override
      public String getDisplayName() {
        return SqlBundle.message("settings.smart.keys.on.collisions");
      }
    },
    NOT_QUALIFY {
      @Override
      public boolean shouldQualify(int conflictedObjectsCount) {
        return false;
      }

      @NotNull
      @Override
      public QualificationType and(@NotNull QualificationType type) {
        return this;
      }

      @NotNull
      @Override
      public String getDisplayName() {
        return SqlBundle.message("settings.smart.keys.never");
      }
    };

    public abstract boolean shouldQualify(int conflictedObjectsCount);

    @NotNull
    public abstract QualificationType and(@NotNull QualificationType type);

    @NotNull
    public abstract String getDisplayName();
  }

  private static class QualificationTypeConverter extends Converter<QualificationType> {
    private static final QualificationType[] ENUM_VALUES = QualificationType.values();

    @NotNull
    @Override
    public QualificationType fromString(@NotNull String value) {
      for (QualificationType enumValue : ENUM_VALUES) {
        if (value.equals(enumValue.name())) return enumValue;
      }
      return switch (value) {
        case "Never" -> QualificationType.NOT_QUALIFY;
        case "Always" -> QualificationType.ALWAYS;
        default -> QualificationType.SMART;
      };
    }

    @NotNull
    @Override
    public String toString(@NotNull QualificationType value) {
      return value.name();
    }
  }
}
