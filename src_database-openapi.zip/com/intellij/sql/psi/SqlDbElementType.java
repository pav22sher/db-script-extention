package com.intellij.sql.psi;

import com.intellij.database.model.ObjectKind;
import com.intellij.util.containers.JBIterable;
import org.jetbrains.annotations.NotNull;

import java.util.Map;

/**
 * @author Gregory.Shrago
 */
public class SqlDbElementType extends ObjectKind {
  public static final ObjectKind ANY = new ObjectKind("ANY");
  
  public static final ObjectKind LOCAL_ALIAS = new ObjectKind("ALIAS");
  public static final ObjectKind CHARSET = new SqlDbElementType("CHARSET", SCHEMA);
  public static final ObjectKind CHECK_RULE = new SqlDbElementType("CHECK RULE", SCHEMA);
  public static final ObjectKind TRANSLATION = new SqlDbElementType("TRANSLATION", SCHEMA);
  public static final ObjectKind ASSERTION = new SqlDbElementType("ASSERTION", SCHEMA);
  public static final ObjectKind QUERY_PARAMETER = new ObjectKind("QUERY_PARAMETER");
  public static final ObjectKind CONSTRAINT = new SqlDbElementType("CONSTRAINT", TABLE);
  public static final ObjectKind INDEXTYPE = new SqlDbElementType("INDEX TYPE", SCHEMA);
  public static final ObjectKind WINDOW = new ObjectKind("WINDOW");
  public static final ObjectKind SYSTEM_VARIABLE = new ObjectKind("SYSTEM_VARIABLE");
  public static final ObjectKind CONDITION = new ObjectKind("CONDITION");
  public static final ObjectKind CURSOR = new ObjectKind("CURSOR");
  public static final ObjectKind DIRECTORY = new ObjectKind("DIRECTORY");
  public static final ObjectKind LABEL = new ObjectKind("LABEL");
  public static final ObjectKind LIBRARY = new ObjectKind("library");
  public static final ObjectKind POLICY = SECURITY_POLICY;
  public static final ObjectKind PROFILE = new ObjectKind("PROFILE");
  public static final ObjectKind SAVEPOINT = new ObjectKind("SAVEPOINT");
  public static final ObjectKind SERVICE = new ObjectKind("SERVICE");
  public static final ObjectKind STATEMENT = new ObjectKind("STATEMENT");
  public static final ObjectKind STATISTICS = new ObjectKind("STATISTICS");
  public static final ObjectKind WORKLOAD = new ObjectKind("WORKLOAD");
  public static final ObjectKind FIELD = new ObjectKind("FIELD");
  public static final ObjectKind GENERIC_AT_LINK = new ObjectKind("@LINK");
  public static final ObjectKind POOL = new ObjectKind("POOL");
  public static final ObjectKind COLUMN_ALIAS = new ObjectKind("COLUMN_ALIAS");
  public static final ObjectKind TRANSFORM = new ObjectKind("TRANSFORM");
  public static final ObjectKind ROW_ACCESS_POLICY = new ObjectKind("ROW_ACCESS_POLICY");

  public final ObjectKind parentType;

  public SqlDbElementType(@NotNull String name, ObjectKind parentType) {
    super(name);
    this.parentType = parentType;
  }

  public static final Map<String, ObjectKind> ourSqlKinds = JBIterable.<ObjectKind>of(
  ).toMap(ObjectKind::code, x -> x);
}
