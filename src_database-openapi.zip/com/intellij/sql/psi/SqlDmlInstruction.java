package com.intellij.sql.psi;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public interface SqlDmlInstruction extends SqlElement {
  @Nullable
  SqlExpression getTargetExpression();

  @NotNull
  List<SqlReferenceExpression> getTargetColumnReferences();

  SqlTableType getTargetType();

}
