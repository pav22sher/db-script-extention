package com.intellij.sql.psi;

import com.intellij.sql.SqlBundle;
import org.jetbrains.annotations.Nls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public enum SqlFileResolveMode {
  SCRIPT("resolve.mode.script.name", "resolve.mode.script.description"),
  PLAYGROUND("resolve.mode.playground.name", "resolve.mode.playground.description");

  private final String myNameKey;
  private final String myDescriptionKey;

  SqlFileResolveMode(@NotNull String nameKey, @NotNull String key) {
    myNameKey = nameKey;
    myDescriptionKey = key;
  }

  @Nls
  @NotNull
  public final String getDisplayName() {
    return SqlBundle.message(myNameKey);
  }

  @Nls
  @NotNull
  public final String getDescription() {
    return SqlBundle.message(myDescriptionKey);
  }

  @NotNull
  public final String serialize() {
    return name();
  }

  @Nullable
  public static SqlFileResolveMode deserialize(@Nullable String s) {
    if (s == null) return null;
    try {
      return valueOf(s);
    }
    catch (Exception e) {
      return null;
    }
  }
}
