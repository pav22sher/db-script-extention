package com.intellij.sql.psi;

/**
 * @author Gregory.Shrago
 */
public interface SqlGroupByClause extends SqlQueryClause {
}