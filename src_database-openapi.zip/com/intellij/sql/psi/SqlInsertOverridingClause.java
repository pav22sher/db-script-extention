package com.intellij.sql.psi;

public interface SqlInsertOverridingClause extends SqlClause {
}
