package com.intellij.sql.psi;

/**
 * @author Gregory.Shrago
 */
public interface SqlIntersectExpression extends SqlSetOperatorExpression {
}
