package com.intellij.sql.psi;

public interface SqlPivotColumnsClause extends SqlClause {
}
