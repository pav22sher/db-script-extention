package com.intellij.sql.psi;

import com.intellij.database.types.DasType;
import org.jetbrains.annotations.NotNull;

public class SqlPrimitiveType extends SqlType {
  private final DasType myDasType;

  public SqlPrimitiveType(@NotNull DasType dasType) {
    myDasType = dasType;
  }

  @NotNull
  @Override
  public DasType getDasType() {
    return myDasType;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;
    SqlPrimitiveType type = (SqlPrimitiveType)o;
    return myDasType.equals(type.myDasType);
  }

  @Override
  public int hashCode() {
    return myDasType.hashCode();
  }
}