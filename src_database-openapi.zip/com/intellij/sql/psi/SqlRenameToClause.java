package com.intellij.sql.psi;

public interface SqlRenameToClause extends SqlClause, SqlSynonymDefinition {
}