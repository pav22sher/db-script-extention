package com.intellij.sql.psi;

public interface SqlRollbackStatement extends SqlStatement {
}
