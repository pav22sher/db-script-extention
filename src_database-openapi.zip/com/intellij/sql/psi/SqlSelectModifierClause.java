package com.intellij.sql.psi;

import org.jetbrains.annotations.NotNull;

public interface SqlSelectModifierClause extends SqlClause {
  @NotNull
  SqlTableType adjustQueryType(@NotNull SqlTableType type);
}
