package com.intellij.sql.psi;

public interface SqlSpecialLiteralExpression extends SqlLiteralExpression {
  boolean isNull();
}
