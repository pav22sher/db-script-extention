package com.intellij.sql.psi;

public interface SqlToken extends SqlElement {
}
