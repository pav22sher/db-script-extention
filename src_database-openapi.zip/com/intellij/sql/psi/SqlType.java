package com.intellij.sql.psi;

import com.intellij.database.types.DasType;
import com.intellij.database.types.DasTypeFacade;
import org.jetbrains.annotations.NotNull;

/**
 * @author Gregory.Shrago
 */
public abstract class SqlType {
  /**
   * @deprecated Use DasType.getDescription() instead
   */
  @Deprecated(forRemoval = true)
  @NotNull
  public final String getDisplayName() {
    return getDasType().getDescription();
  }

  @NotNull
  public abstract DasType getDasType();

  /**
   * @deprecated SqlType is superseded by DasType, so avoid using it in the IntelliJ code
   * This constant exists only for backward compatibility with third-party plugins
   */
  @Deprecated(forRemoval = true)
  public static final SqlPrimitiveType UNKNOWN = new SqlPrimitiveType(DasTypeFacade.getInstance().getUnknown());

  public static final SqlType UNKNOWN_TYPE = new SqlType() {
    @NotNull
    @Override
    public DasType getDasType() {
      return DasTypeFacade.getInstance().getUnknown();
    }
  };

  @Override
  public String toString() {
    return getDasType().getDescription();
  }
}
