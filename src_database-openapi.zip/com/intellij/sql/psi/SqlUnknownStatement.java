package com.intellij.sql.psi;

public interface SqlUnknownStatement extends SqlStatement {
}
