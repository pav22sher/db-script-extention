package com.intellij.sql.psi;

import com.intellij.database.model.DasUserDefinedType;
import org.jetbrains.annotations.Nullable;

public interface SqlUserTypeDefinition extends SqlDefinition, DasUserDefinedType {
  @Nullable
  SqlReferenceExpression getSuperTypeReference();

  @Nullable
  SqlTypeElement getAliasedTypeElement();
}