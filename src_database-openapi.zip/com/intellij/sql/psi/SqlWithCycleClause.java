package com.intellij.sql.psi;

public interface SqlWithCycleClause extends SqlClause {
}
