/*
 * Copyright 2000-2016 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package icons;

import com.intellij.ui.IconManager;
import org.jetbrains.annotations.NotNull;

import javax.swing.*;

/**
 * NOTE THIS FILE IS AUTO-GENERATED
 * DO NOT EDIT IT BY HAND, run "Generate icon classes" configuration instead
 */
public final class DatabaseIcons {
  private static @NotNull Icon load(@NotNull String path, int cacheKey, int flags) {
    return IconManager.getInstance().loadRasterizedIcon(path, DatabaseIcons.class.getClassLoader(), cacheKey, flags);
  }
  /** 16x16 */ public static final @NotNull Icon Access_method = load("icons/access_method.svg", -1055676306, 0);
  /** 16x16 */ public static final @NotNull Icon Adapter_script = load("icons/adapter_script.svg", -838490380, 0);
  /** 10x10 */ public static final @NotNull Icon AddHover = load("icons/add-hover.svg", -13874693, 2);
  /** 10x10 */ public static final @NotNull Icon Add = load("icons/add.svg", -842706450, 2);
  /** 16x16 */ public static final @NotNull Icon Aggregate = load("icons/aggregate.svg", -1529898658, 0);
  /** 16x16 */ public static final @NotNull Icon Argument = load("icons/argument.svg", 1758604384, 0);
  /** 16x16 */ public static final @NotNull Icon BinaryData = load("icons/binaryData.svg", -193846066, 2);
  /** 16x16 */ public static final @NotNull Icon BlueKey = load("icons/blueKey.svg", -353231680, 0);
  /** 16x16 */ public static final @NotNull Icon BlueKeyTrigger = load("icons/blueKeyTrigger.svg", -785141999, 0);
  /** 16x16 */ public static final @NotNull Icon Body = load("icons/body.svg", -2054952767, 0);
  /** 16x16 */ public static final @NotNull Icon CheckConstraint = load("icons/checkConstraint.svg", -830941548, 0);
  /** 16x16 */ public static final @NotNull Icon Col = load("icons/col.svg", 2030169193, 0);
  /** 16x16 */ public static final @NotNull Icon ColBlueKey = load("icons/colBlueKey.svg", -1590527913, 0);
  /** 16x16 */ public static final @NotNull Icon ColBlueKeyDot = load("icons/colBlueKeyDot.svg", 1179885322, 2);
  /** 16x16 */ public static final @NotNull Icon ColBlueKeyDotIndex = load("icons/colBlueKeyDotIndex.svg", -1420245026, 2);
  /** 16x16 */ public static final @NotNull Icon ColBlueKeyIndex = load("icons/colBlueKeyIndex.svg", 1226634948, 0);
  /** 16x16 */ public static final @NotNull Icon ColDot = load("icons/colDot.svg", 1775098257, 2);
  /** 16x16 */ public static final @NotNull Icon ColDotIndex = load("icons/colDotIndex.svg", -7419329, 2);
  /** 16x16 */ public static final @NotNull Icon ColGoldBlueKey = load("icons/colGoldBlueKey.svg", -661714957, 0);
  /** 16x16 */ public static final @NotNull Icon ColGoldBlueKeyDot = load("icons/colGoldBlueKeyDot.svg", 576752950, 2);
  /** 16x16 */ public static final @NotNull Icon ColGoldBlueKeyDotIndex = load("icons/colGoldBlueKeyDotIndex.svg", -1198320144, 2);
  /** 16x16 */ public static final @NotNull Icon ColGoldBlueKeyIndex = load("icons/colGoldBlueKeyIndex.svg", -1653485801, 0);
  /** 16x16 */ public static final @NotNull Icon ColGoldKey = load("icons/colGoldKey.svg", -1010594134, 0);
  /** 16x16 */ public static final @NotNull Icon ColGoldKeyDot = load("icons/colGoldKeyDot.svg", 1187079886, 2);
  /** 16x16 */ public static final @NotNull Icon ColGoldKeyDotIndex = load("icons/colGoldKeyDotIndex.svg", -1401413033, 2);
  /** 16x16 */ public static final @NotNull Icon ColGoldKeyIndex = load("icons/colGoldKeyIndex.svg", 229305735, 0);
  /** 16x16 */ public static final @NotNull Icon ColGreyKey = load("icons/colGreyKey.svg", -1469042399, 0);
  /** 16x16 */ public static final @NotNull Icon ColIndex = load("icons/colIndex.svg", -134720597, 0);
  /** 16x16 */ public static final @NotNull Icon Collation = load("icons/collation.svg", 1394437239, 0);
  /** 16x16 */ public static final @NotNull Icon Collection = load("icons/collection.svg", 1286346859, 0);
  /** 16x16 */ public static final @NotNull Icon CollectionKey = load("icons/collectionKey.svg", -1222826429, 0);
  /** 16x16 */ public static final @NotNull Icon CollectionType = load("icons/collectionType.svg", -1417083788, 0);
  /** 16x16 */ public static final @NotNull Icon Commit = load("icons/commit.svg", 1744565374, 2);
  /** 16x16 */ public static final @NotNull Icon Connector = load("icons/connector.svg", 2143824790, 0);
  /** 16x16 */ public static final @NotNull Icon ConsoleRun = load("icons/consoleRun.svg", -1811532591, 2);
  /** 16x16 */ public static final @NotNull Icon ConsoleShowPlan = load("icons/consoleShowPlan.svg", 391153812, 2);
  /** 16x16 */ public static final @NotNull Icon Constant = load("icons/constant.svg", -320331175, 0);
  /** 16x16 */ public static final @NotNull Icon Database = load("icons/database.svg", -2135323884, 0);
  /** 16x16 */ public static final @NotNull Icon DatabaseExternal = load("icons/databaseExternal.svg", -674449447, 2);
  /** 16x16 */ public static final @NotNull Icon DatabaseLink = load("icons/databaseLink.svg", 428370229, 2);
  /** 16x16 */ public static final @NotNull Icon DatabaseObjGroup = load("icons/databaseObjGroup.svg", -1293438449, 0);
  /** 16x16 */ public static final @NotNull Icon DataFile = load("icons/dataFile.svg", 376341798, 0);
  /** 16x16 */ public static final @NotNull Icon DataShare = load("icons/dataShare.svg", 314917219, 2);
  /** 16x16 */ public static final @NotNull Icon Dbms = load("icons/dbms.svg", 1040672733, 0);
  /** 16x16 */ public static final @NotNull Icon DdlDbms = load("icons/ddlDbms.svg", -1425742426, 1);
  /** 16x16 */ public static final @NotNull Icon DefaultConstraint = load("icons/defaultConstraint.svg", 876577531, 0);
  /** 16x16 */ public static final @NotNull Icon DriverBlue1 = load("icons/driverBlue1.svg", 368597287, 0);
  /** 16x16 */ public static final @NotNull Icon DriverBlue2 = load("icons/driverBlue2.svg", 1606488632, 0);
  /** 16x16 */ public static final @NotNull Icon DriverBlue3 = load("icons/driverBlue3.svg", 516649814, 0);
  /** 16x16 */ public static final @NotNull Icon DriverBlue4 = load("icons/driverBlue4.svg", -122057488, 0);
  /** 16x16 */ public static final @NotNull Icon DriverGreen1 = load("icons/driverGreen1.svg", 479851894, 0);
  /** 16x16 */ public static final @NotNull Icon DriverGreen2 = load("icons/driverGreen2.svg", -513082356, 0);
  /** 16x16 */ public static final @NotNull Icon DriverGreen3 = load("icons/driverGreen3.svg", 775786587, 0);
  /** 16x16 */ public static final @NotNull Icon DriverGreen4 = load("icons/driverGreen4.svg", -1593986069, 0);
  /** 16x16 */ public static final @NotNull Icon DriverPink1 = load("icons/driverPink1.svg", -492035485, 0);
  /** 16x16 */ public static final @NotNull Icon DriverPink2 = load("icons/driverPink2.svg", -2030424330, 0);
  /** 16x16 */ public static final @NotNull Icon DriverPink3 = load("icons/driverPink3.svg", 706594158, 0);
  /** 16x16 */ public static final @NotNull Icon DriverPink4 = load("icons/driverPink4.svg", 1672668259, 0);
  /** 16x16 */ public static final @NotNull Icon DriverRed1 = load("icons/driverRed1.svg", -1224149811, 0);
  /** 16x16 */ public static final @NotNull Icon DriverRed2 = load("icons/driverRed2.svg", -1997150149, 0);
  /** 16x16 */ public static final @NotNull Icon DriverRed3 = load("icons/driverRed3.svg", -1937923655, 0);
  /** 16x16 */ public static final @NotNull Icon DriverRed4 = load("icons/driverRed4.svg", 1163242747, 0);
  /** 16x16 */ public static final @NotNull Icon EditData = load("icons/editData.svg", 1555307167, 0);
  /** 16x16 */ public static final @NotNull Icon EditorOutput = load("icons/editorOutput.svg", -254139672, 2);
  /** 16x16 */ public static final @NotNull Icon Extension = load("icons/extension.svg", 1315620132, 0);
  /** 14x14 */ public static final @NotNull Icon External_link_arrow = load("icons/external_link_arrow.svg", 1309507344, 0);
  /** 16x16 */ public static final @NotNull Icon External_schema_object = load("icons/external_schema_object.svg", -628124315, 2);
  /** 16x16 */ public static final @NotNull Icon FileFormat = load("icons/fileFormat.svg", -990062316, 0);

  public static final class FileTypes {
    /** 16x16 */ public static final @NotNull Icon CassandraFileType = load("icons/fileTypes/cassandraFileType.svg", -1072370786, 0);
    /** 16x16 */ public static final @NotNull Icon HiveFileType = load("icons/fileTypes/hiveFileType.svg", 2082050941, 0);
    /** 16x16 */ public static final @NotNull Icon RedisFileType = load("icons/fileTypes/redisFileType.svg", -1376772455, 0);
  }

  /** 16x16 */ public static final @NotNull Icon Foreign_datawrapper = load("icons/foreign_datawrapper.svg", 1795750418, 2);
  /** 16x16 */ public static final @NotNull Icon Foreign_server = load("icons/foreign_server.svg", -803405812, 2);
  /** 16x16 */ public static final @NotNull Icon Foreign_table = load("icons/foreign_table.svg", -1983676386, 2);
  /** 16x16 */ public static final @NotNull Icon Function = load("icons/function.svg", 343738095, 1);
  /** 16x16 */ public static final @NotNull Icon FunctionExternal = load("icons/functionExternal.svg", 1681564923, 2);
  /** 16x16 */ public static final @NotNull Icon FunctionRun = load("icons/functionRun.svg", -395478413, 1);
  /** 16x16 */ public static final @NotNull Icon FunnelGray = load("icons/funnel-gray.svg", 1417606625, 0);
  /** 16x16 */ public static final @NotNull Icon FunnelHover = load("icons/funnel-hover.svg", 848200152, 0);
  /** 16x16 */ public static final @NotNull Icon FunnelSelected = load("icons/funnel-selected.svg", 1916086965, 0);
  /** 16x16 */ public static final @NotNull Icon GoldKey = load("icons/goldKey.svg", -1243307279, 0);
  /** 16x16 */ public static final @NotNull Icon GoldKeyAlt = load("icons/goldKeyAlt.svg", -1145814233, 0);
  /** 16x16 */ public static final @NotNull Icon GreenBugOverlap = load("icons/greenBugOverlap.svg", -1346583420, 2);
  /** 16x16 */ public static final @NotNull Icon HashCluster = load("icons/hashCluster.svg", -228543640, 2);
  /** 16x16 */ public static final @NotNull Icon HashTable = load("icons/hashTable.svg", -1732331275, 0);
  /** 16x16 */ public static final @NotNull Icon HashTableKey = load("icons/hashTableKey.svg", -516159475, 0);
  /** 16x16 */ public static final @NotNull Icon Index = load("icons/index.svg", 452912529, 0);
  /** 16x16 */ public static final @NotNull Icon IndexCluster = load("icons/indexCluster.svg", -1170048496, 0);
  /** 16x16 */ public static final @NotNull Icon IndexFun = load("icons/indexFun.svg", -1446156592, 2);
  /** 16x16 */ public static final @NotNull Icon IndexUnique = load("icons/indexUnique.svg", 668080012, 2);
  /** 16x16 */ public static final @NotNull Icon IndexUniqueFun = load("icons/indexUniqueFun.svg", -391010307, 2);
  /** 16x16 */ public static final @NotNull Icon KillDataSourceProcess = load("icons/killDataSourceProcess.svg", 653693100, 2);
  /** 12x16 */ public static final @NotNull Icon Level1 = load("icons/level1.svg", 56277327, 0);
  /** 16x16 */ public static final @NotNull Icon Level1_declared = load("icons/level1_declared.svg", 1006237711, 2);
  /** 16x16 */ public static final @NotNull Icon Level1_details = load("icons/level1_details.svg", 1724647824, 0);
  /** 16x16 */ public static final @NotNull Icon Level1_inherited = load("icons/level1_inherited.svg", -1741664847, 2);
  /** 12x16 */ public static final @NotNull Icon Level2 = load("icons/level2.svg", -199975841, 0);
  /** 16x16 */ public static final @NotNull Icon Level2_declared = load("icons/level2_declared.svg", -1567600327, 2);
  /** 16x16 */ public static final @NotNull Icon Level2_details = load("icons/level2_details.svg", -1616670670, 0);
  /** 16x16 */ public static final @NotNull Icon Level2_inherited = load("icons/level2_inherited.svg", 1045413144, 2);
  /** 12x16 */ public static final @NotNull Icon Level3 = load("icons/level3.svg", -693304516, 0);
  /** 16x16 */ public static final @NotNull Icon Level3_declared = load("icons/level3_declared.svg", 1421456286, 2);
  /** 16x16 */ public static final @NotNull Icon Level3_details = load("icons/level3_details.svg", -96229229, 0);
  /** 16x16 */ public static final @NotNull Icon Level3_inherited = load("icons/level3_inherited.svg", -787655796, 2);
  /** 16x16 */ public static final @NotNull Icon List = load("icons/list.svg", 407442786, 0);
  /** 16x16 */ public static final @NotNull Icon ListKey = load("icons/listKey.svg", 2053186583, 0);
  /** 16x16 */ public static final @NotNull Icon Macro = load("icons/macro.svg", 1907585797, 1);
  /** 16x16 */ public static final @NotNull Icon ManageDataSources = load("icons/manageDataSources.svg", -536353214, 2);
  /** 16x16 */ public static final @NotNull Icon MaterializedLog = load("icons/materializedLog.svg", -803375705, 2);
  /** 16x16 */ public static final @NotNull Icon MaterializedView = load("icons/materializedView.svg", -1361862783, 2);
  /** 16x16 */ public static final @NotNull Icon MongoField = load("icons/mongoField.svg", 1870606974, 0);
  /** 16x16 */ public static final @NotNull Icon MongoFieldGoldKey = load("icons/mongoFieldGoldKey.svg", -1696725396, 0);
  /** 16x16 */ public static final @NotNull Icon ObjectGroup = load("icons/objectGroup.svg", -50640430, 0);
  /** 16x16 */ public static final @NotNull Icon Operator = load("icons/operator.svg", -1302779534, 0);
  /** 16x16 */ public static final @NotNull Icon OperatorClass = load("icons/operatorClass.svg", 70397706, 0);
  /** 16x16 */ public static final @NotNull Icon OperatorFamily = load("icons/operatorFamily.svg", 621815462, 0);
  /** 16x16 */ public static final @NotNull Icon Package = load("icons/package.svg", -1352408623, 0);
  /** 16x16 */ public static final @NotNull Icon Partition = load("icons/partition.svg", -1420612674, 0);
  /** 16x16 */ public static final @NotNull Icon PreviewChanges = load("icons/previewChanges.svg", -255808598, 2);
  /** 16x16 */ public static final @NotNull Icon Procedure = load("icons/procedure.svg", 1397575265, 0);
  /** 16x16 */ public static final @NotNull Icon ProcedureRun = load("icons/procedureRun.svg", 1817891112, 0);
  /** 16x16 */ public static final @NotNull Icon ProcGroup = load("icons/procGroup.svg", -322822106, 1);
  /** 16x16 */ public static final @NotNull Icon Projection = load("icons/projection.svg", -1685513223, 2);
  /** 16x16 */ public static final @NotNull Icon Role = load("icons/role.svg", -1152018049, 0);
  /** 16x16 */ public static final @NotNull Icon RollbackDB = load("icons/rollbackDB.svg", -2016540946, 2);
  /** 16x16 */ public static final @NotNull Icon Routine = load("icons/routine.svg", -2066493011, 0);
  /** 16x16 */ public static final @NotNull Icon Rule = load("icons/rule.svg", -498362838, 0);
  /** 16x16 */ public static final @NotNull Icon RunDatabaseScript = load("icons/runDatabaseScript.svg", -1310468914, 2);
  /** 16x16 */ public static final @NotNull Icon ScheduledEvent = load("icons/scheduledEvent.svg", 940950341, 0);
  /** 16x16 */ public static final @NotNull Icon Schema = load("icons/schema.svg", 707394180, 0);
  /** 16x16 */ public static final @NotNull Icon Scripting_script = load("icons/scripting_script.svg", -753948331, 2);
  /** 16x16 */ public static final @NotNull Icon Sequence = load("icons/sequence.svg", -17548192, 0);
  /** 16x16 */ public static final @NotNull Icon ServerObjGroup = load("icons/serverObjGroup.svg", -2105018351, 0);
  /** 16x16 */ public static final @NotNull Icon Set = load("icons/set.svg", 8668369, 0);
  /** 16x16 */ public static final @NotNull Icon SetKey = load("icons/setKey.svg", -1801692343, 0);
  /** 16x16 */ public static final @NotNull Icon SortedSet = load("icons/sortedSet.svg", 1822845525, 0);
  /** 16x16 */ public static final @NotNull Icon SortedSetKey = load("icons/sortedSetKey.svg", 1478542708, 0);
  /** 16x16 */ public static final @NotNull Icon Sql = load("icons/sql.svg", -1612991105, 0);
  /** 16x16 */ public static final @NotNull Icon SqlDmlStatement = load("icons/sqlDmlStatement.svg", 1912811530, 0);
  /** 16x16 */ public static final @NotNull Icon SqlGroupByType = load("icons/sqlGroupByType.svg", -673453569, 2);
  /** 16x16 */ public static final @NotNull Icon SqlOtherStatement = load("icons/sqlOtherStatement.svg", -879280565, 0);
  /** 16x16 */ public static final @NotNull Icon SqlSelectStatement = load("icons/sqlSelectStatement.svg", -688857351, 0);
  /** 16x16 */ public static final @NotNull Icon Stream = load("icons/stream.svg", 524212429, 0);
  /** 16x16 */ public static final @NotNull Icon StreamKey = load("icons/streamKey.svg", 359518849, 0);
  /** 16x16 */ public static final @NotNull Icon String = load("icons/string.svg", 183048464, 0);
  /** 16x16 */ public static final @NotNull Icon StringKey = load("icons/stringKey.svg", -2110517538, 0);
  /** 16x16 */ public static final @NotNull Icon SubmitDB = load("icons/submitDB.svg", 827887171, 2);
  /** 16x16 */ public static final @NotNull Icon SuspendScaled = load("icons/suspendScaled.svg", -311817519, 2);
  /** 16x16 */ public static final @NotNull Icon Synonym = load("icons/synonym.svg", -773512786, 2);
  /** 16x16 */ public static final @NotNull Icon Table = load("icons/table.svg", -1733721981, 0);
  /** 16x16 */ public static final @NotNull Icon TableMapping = load("icons/tableMapping.svg", -1057647574, 0);
  /** 16x16 */ public static final @NotNull Icon Tablespace = load("icons/tablespace.svg", -396480697, 0);
  /** 16x16 */ public static final @NotNull Icon TextAutoGenerate = load("icons/textAutoGenerate.svg", 490263969, 2);
  /** 13x13 */ public static final @NotNull Icon ToolWindowConsole = load("icons/toolWindowConsole.svg", -922103279, 2);
  /** 13x13 */ public static final @NotNull Icon ToolWindowDatabase = load("icons/toolWindowDatabase.svg", 499223975, 2);
  /** 13x13 */ public static final @NotNull Icon ToolwindowDatabaseChanges = load("icons/toolwindowDatabaseChanges.svg", -1715712369, 2);
  /** 13x13 */ public static final @NotNull Icon ToolWindowFiles = load("icons/toolWindowFiles.svg", 1576591296, 2);
  /** 13x13 */ public static final @NotNull Icon ToolWindowSQLGenerator = load("icons/toolWindowSQLGenerator.svg", -1543515315, 2);
  /** 16x16 */ public static final @NotNull Icon Trigger = load("icons/trigger.svg", -43240388, 0);
  /** 16x16 */ public static final @NotNull Icon TSQLt = load("icons/tSQLt.svg", -2069289180, 2);
  /** 16x16 */ public static final @NotNull Icon Udf_script = load("icons/udf_script.svg", 920930411, 2);
  /** 16x16 */ public static final @NotNull Icon UnspecifiedCluster = load("icons/unspecifiedCluster.svg", -833557945, 0);
  /** 16x16 */ public static final @NotNull Icon User_mapping = load("icons/user_mapping.svg", 935102232, 0);
  /** 16x16 */ public static final @NotNull Icon UserDriver = load("icons/userDriver.svg", -553862162, 0);
  /** 16x16 */ public static final @NotNull Icon UtPLSQL = load("icons/utPLSQL.svg", 1673105545, 0);
  /** 16x16 */ public static final @NotNull Icon ViewParameters = load("icons/viewParameters.svg", -165432339, 0);
  /** 16x16 */ public static final @NotNull Icon VirtualColumn = load("icons/virtualColumn.svg", -1079893675, 0);
  /** 16x16 */ public static final @NotNull Icon VirtualFolder = load("icons/virtualFolder.svg", 1229680778, 0);
  /** 16x16 */ public static final @NotNull Icon VirtualForeignKey = load("icons/virtualForeignKey.svg", -1446649346, 0);
  /** 16x16 */ public static final @NotNull Icon VirtualView = load("icons/virtualView.svg", 927029680, 0);
  /** 16x16 */ public static final @NotNull Icon Warehouse = load("icons/warehouse.svg", -486611570, 0);
}
